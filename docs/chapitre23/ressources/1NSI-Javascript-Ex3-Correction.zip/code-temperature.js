//gestionnaire d'événement clic pour l'élément bouton
function conversion_unite(){
    let u = document.getElementById("unite_source");
    let m = document.getElementById("mesure_source");
    let c = document.getElementById("unite_cible");
    let v = document.getElementById("valeur");
    if (u.value === 'celsius'){
        v.innerHTML = 9/5 * parseInt(m.value) + 32;
        c.innerHTML = 'fahrenheit';
    }
    else {
        v.innerHTML = 5/9 * (parseInt(m.value) - 32);
        c.innerHTML = 'celsius';
    }    
}

//on attache un gestionnaire d'événement à l'élément #bouton
let bouton = document.getElementById("bouton");
bouton.addEventListener("click",conversion_unite);
//conversion par défaut au chargement de la page
conversion_unite();

