<!DOCTYPE html>

<!-- Script PHP d'initialisation -->
<?php
if (isset($_POST['mesure_source'])) {
    $mesure_source = $_POST['mesure_source'];    
}
else {
    $mesure_source =  0;
}

if (isset($_POST['unite_source'])) {
    $unite_source = $_POST['unite_source'];    
}
else {
    $unite_source =  'celsius';
}

if ($unite_source == 'celsius'){
    $unite_cible = 'fahrenheit';
}
else {
    $unite_cible = 'celsius';
}

function conversion($mesure, $unite){
    if ($unite == 'celsius') {
        return $mesure * 9 / 5 + 32;
    }
    else {
        return ($mesure + 32 )* 5 / 9;
    }
}

function selection_unite($unite, $unite_cible) {
    if ($unite == $unite_cible) {
        return "selected";
    }
    else {
        return "";
    }
}
?>
<!-- fin du script PHP -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de l'âge avec PHP </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

 <h1> Conversion d'unité d'une mesure de température.  </h1>
   
    <form action="temperature.php" method="POST">
        
        <label for="unite_source">Choisir l'unité de la mesure source :</label>
        <select name="unite_source" id="unite_source">
            <option value="celsius" <?php echo selection_unite('celsius', $unite_cible) ?> >Celsius</option>
            <option value="fahrenheit" <?php echo selection_unite('celsius', $unite_cible) ?>>Fahrenheit</option>
        </select>
        <br>
        <label for="mesure_source">Saisir la mesure de température dans l'unité source : </label>
        <input type="number" id="mesure_source" name="mesure_source" value=<?php echo $mesure_source ?> >
        <br>
        <button type="submit">Convertir</button>
        <br>
        <label>Conversion en <?php echo $unite_cible  ?> </label>
        <input type="text" value=<?php echo conversion($mesure_source, $unite_source) ?> >

    </form>
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
