<!DOCTYPE html>

<!-- Script PHP d'initialisation -->
<?php
if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];    
}
else if (isset($_GET['nombre'])) {
    $nombre = $_GET['nombre'];    
}
else {
    $nombre = 0;
}
?>

<!-- fin du script PHP -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de l'âge avec PHP </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<h1> Table des 11 premiers multiples d'un entier inférieur ou égal à 10  </h1>
   
    <form action="multiplication.php" method="GET">
        <label>Choix du multiplicateur : </label> 
        <input type="number" name="nombre" min="0" max="10" value=<?php echo $nombre ?> >
        <button type="submit" id="bouton">  Soumettre </button>
    </form>
    
<!-- Script PHP d'affichage de la table de multiplication -->
<?php
echo "<ul>";
for ($i = 0; $i <= 10; $i = $i + 1){
    if ($i % 2 == 1) {
        $style = "'background : rgb(235, 24, 34); color : rgb(255, 219, 69)'";
    }
    else {
        $style = "'background : rgb(255, 219, 69); color : rgb(235, 24, 34)'";
    }
    echo "<li style = " . $style . ">";
    echo $nombre . "x" . $i . "=" . ($nombre * $i);
    echo "</li>\n";
}
echo "</ul>";
?>
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
