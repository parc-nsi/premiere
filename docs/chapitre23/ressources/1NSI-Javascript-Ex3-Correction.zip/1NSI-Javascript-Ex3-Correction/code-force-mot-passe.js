//gestionnaire d'événement clic pour l'élément bouton
function calculer_taille_clef(){
    let c = document.getElementById("caractere");
    let a = document.getElementById("alphabet");
    let s = parseInt(a.value) ** parseInt(c.value);
    let k = 1;
    let p = 1;
    while (p <= s) {
        p = p * 2;
        k = k + 1;
    }
    let b = document.getElementById("bits");     
    b.value = k;
    let f = document.getElementById("force"); 
    if (k  < 64){
        f.value = "très faible"  ;
    }
    else if ( k < 80){
        f.value = "faible"  ;
    }
    else if ( k < 100){
        f.value = "moyenne"  ;
    }
    else {
        f.value = "forte"  ;
    }

}

//on attache un gestionnaire d'événement à l'élément #bouton
let bouton = document.getElementById("bouton");
bouton.addEventListener("click",calculer_taille_clef);


