//gestionnaire d'événement clic pour l'élément bouton
function calculer_taille_clef(){
    let c = document.getElementById("caractere");
    let a = document.getElementById("alphabet");
    /* la variable s va contenir le nombre de possibilités avec un mot de passe de c caractères sur un alphabet de a lettres
    */
    let s = parseInt(a.value) ** parseInt(c.value);
    /*A compléter : il reste à calculer la longueur minimale 
    de la clef équivalente en bits (alphabet binaire de 2 lettres)
    puis à mettre à jour les valeurs des éléments d'identifiants
    #bits et #force pour avoir un résultat équivalent à celui du formulaire
    de l'ANSSI : https://www.ssi.gouv.fr/administration/precautions-elementaires/calculer-la-force-dun-mot-de-passe/
    */
    let b = document.getElementById("bits");     
    let f = document.getElementById("force");

}

//on attache un gestionnaire d'événement à l'élément #bouton
let bouton = document.getElementById("bouton");
bouton.addEventListener("click",calculer_taille_clef);


