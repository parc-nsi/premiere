<!DOCTYPE html>

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Colorpicker </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

  <form   action="rgb.php" method="GET">
    <label for="r">Composante rouge R</label>
    <input type="number" id="r" name="r" min="0" max="255" value= "0" >
    <br>
    <label for="g">Composante verte G</label>
    <input type="number" id="g" name="g" min="0" max="255" value= "0" >
    <br>
    <label for="b">Composante bleue B</label>
    <input type="number" id="b" name="b" min="0" max="255" value= "0" >
    <br>
    <button type="submit" id="bouton">Afficher</button>
</form>


<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
