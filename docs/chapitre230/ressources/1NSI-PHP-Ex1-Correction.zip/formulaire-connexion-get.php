<!DOCTYPE html>

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Connexion GET </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

   
   <h1> Formulaire de connexion avec la méthode GET </h1>
   
    <form action="login.php" method="GET">
        <label for="ident">Identifiant : </label> 
        <input type="text" id="ident" name="ident" required />
        <label for="pass">Mot de passe : </label> 
        <input type="password" id="pass" name="pass" required />
        <button type="submit">Envoyer</button>    
    </form>
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
