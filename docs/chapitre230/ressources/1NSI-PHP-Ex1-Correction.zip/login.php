<!DOCTYPE html>


<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de l'âge avec PHP </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<div>
<?php
echo "<p> Il est " . date("H:i:s") . "</p>"; 

if ( isset($_GET['ident']) && isset($_GET['pass']) && ( $_GET['pass'] ==   'secret' ) ) {
    echo "<p> Bienvenue " . $_GET['ident'] . "</p>";
}
elseif ( !( empty($_POST['ident']) || empty($_POST['pass']) ) && ( $_POST['pass'] == 'secret' ) ){
    echo "<p>Bienvenue " . $_POST['ident'] . "</p>";
}
else {
    echo "<p> Échec de la connexion. </p>";
}
?>
</div>

<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
