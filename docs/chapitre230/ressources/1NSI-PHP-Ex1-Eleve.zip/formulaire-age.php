<!DOCTYPE html>

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Formulaire de calcul d'âge </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

    <form action="age.php" method="GET">
        <label for="naissance">Saisissez votre date de naissance </label> 
        <br>
        <!-- compléter -->    
    </form>
    
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
