 <!-- Menu -->
 <nav>
 <h2>Menu</h2>

                      
  <ul>
    <li><a  href="index.php">Page d'accueil</a></li>
    <li><a  href="heure.php">Affichage de l'heure.</a></li>
    <li><a href="formulaire-connexion-get.php">Formulaire de connexion avec la méthode GET</a></li>
    <li><a href="formulaire-connexion-post.php">Formulaire de connexion avec la méthode POST</a></li>
    <li><a  href="formulaire-age.php">Formulaire de calcul d'âge</a></li>
    <li><a  href="formulaire-rgb.php">Formulaire d'affichage de couleur (R,G,B)</a></li>
    <li><a  href="temperature.php">Formulaire de changement d'unité de température</a></li>
    <li><a  href="multiplication.php">Formulaire d'affichage de table de multiplication</a></li>
    <li><a href="info.php">PHP Info</a></li>
  </ul>
</nav>