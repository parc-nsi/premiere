from flask import Flask, render_template, request
import datetime

#définition de l'application
app = Flask(__name__)

#routage vers la page d'accueil
@app.route('/')
def defaut():  
  return render_template("index.html")
       
#routage vers le formulaire de calcul d'âge
@app.route('/formulaire_age')
def formulaire_age():
  return render_template("formulaire_age.html")  

#routage vers le controleur de calcul d'âge
@app.route('/age',methods = ['POST', 'GET'])
def age():   
  if request.method == 'POST':
    assert request.form['a'], "Erreur de paramètres"
    annee_naissance = int(request.form['a'])   
  else: #requete GET
    assert request.args['a'], "Erreur de paramètres"
    annee_naissance = int(request.args.get('a', ''))
  annee_courante = datetime.date.today().year
  age = annee_courante - annee_naissance
  return render_template("age.html", annee_naissance = annee_naissance, annee_courante = annee_courante, age = age)

#routage vers le formulaire de saisie des composantes (R,G,B)
@app.route('/formulaire_rgb')
def formulaire_rgb():
  return render_template("formulaire_rgb.html")  

#routage vers le controleur d'affichage de la couleur (R,G,B)
@app.route('/rgb',methods = ['POST', 'GET'])
def rgb():   
  r, g, b = 0, 0, 0
  if request.method == 'POST':
    assert request.form['r'] and request.form['g'] and request.form['b'], "Erreur de paramètres"
    r = int(request.form['r'])
    #à compléter (plusieurs lignes)
  else: #requete GET
    assert request.args['r'] and request.args['g'] and request.args['b'], "Erreur de paramètres"
    #à compléter (plusieurs lignes)
  return render_template("rgb.html", r = r, g = g, b = b, couleur = f'rgb({r}, {g}, {b})')


def conversion_temperature(mesure_source, unite_source):
   #à compléter, doit retourner une chaine de caractères
   if unite_source == 'celsius':
      return "" #compléter
   else:
      return ""  #compléter

#routage vers le controleur du formulaire de conversion de température
@app.route('/temperature',methods = ['POST', 'GET'])
def temperature():
  unite_source = "celsius"
  unite_cible = 'fahrenheit'
  mesure_source = 0
  if request.method == 'POST':
    assert request.form['unite_source'] and request.form['mesure_source'], "Erreur de paramètres"
    unite_source = request.form['unite_source']
    #à compléter
  elif len(request.args) > 0: #requete GET
    assert request.args['unite_source'] and request.args['mesure_source'], "Erreur de paramètres"
    #à compléter (plusieurs lignes)
  if unite_source != 'celsius':       
    unite_cible = 'celsius'
  selection = {unite_source : 'selected', unite_cible : '' }
  return render_template("temperature.html", mesure_source = mesure_source, unite_source = unite_source, unite_cible = unite_cible, 
  selection = selection, conversion = conversion_temperature(mesure_source, unite_source))



if __name__ == "__main__":
  # on ouvre un serveur en local sur le port 8000
  app.run(debug = True, host='0.0.0.0', port=8000)

   