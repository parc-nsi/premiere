<!DOCTYPE html>

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de l'heure avec PHP </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>


   <h1> Affichage de l'heure avec PHP </h1>
   
   <p> Bonjour, il est : <?php echo date("H:i:s") ;?>  </p>



<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
