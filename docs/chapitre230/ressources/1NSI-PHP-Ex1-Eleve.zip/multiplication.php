<!DOCTYPE html>

<!-- Script PHP d'initialisation -->
<?php
//compléter la structure conditionnelle avec la possibilité de choisir la méthode GET
if (isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];    
}
else {
    $nombre = 0;
}
?>

<!-- fin du script PHP -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de table de multiplication </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<h1> Table des 10 premiers multiples d'un entier inférieur ou égal à 10  </h1>
   
    <form action="multiplication.php" method="POST">
        <label for="nombre">Choix du multiplicateur : </label> 
        <input type="number" id="nombre" name="nombre" min="0" max="10" value=<?php  /*à compléter*/ ?> >
        <button type="submit" id="bouton">  Soumettre </button>
    </form>
    
<!-- Script PHP d'affichage de la table de multiplication -->
<?php
echo "<ul>";
for ($i = 0; $i <= 10; $i = $i + 1){
    if ($i % 2 == 1) {
        $style = "'background : black; color : gray'";
    }
    else {
        $style = "'background : gray; color : black'";
    }
    echo "<li style = " . "" /*à compléter*/. ">";
    echo "à compléter"; //compléter avec le produit de $i$ par $nombre
    echo "</li>\n";
}
echo "</ul>";
?>
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
