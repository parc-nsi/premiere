//gestionnaire d'événement clic pour l'élément bouton
function afficher_couleur(){
    let r = document.getElementById("r");
    let g = document.getElementById("g");
    //à compléter et décommenter la ligne suivante
    //c.style.background = "rgb(" + r.value + "," + g.value + "," + b.value  + ")";
}

//on attache un gestionnaire d'événement à l'élément #bouton
let bouton = document.getElementById("bouton");
bouton.addEventListener("click",afficher_couleur);
//conversion par défaut au chargement de la page
afficher_couleur();

