<!DOCTYPE html>

<!-- script php  d'initialisation -->
<?php
if (isset($_GET['r'])) {
    $r = $_GET['r'];
}
else {
    $r = 0;
}

if (isset($_GET['g'])) {
    $g = $_GET['g'];
}
else {
    $g = 0;
}

if (isset($_GET['b'])) {
    $b = $_GET['b'];
}
else {
    $b = 0;
}

$rgb = "rgb(" . $r . "," . $g. "," . $b . ")";
?>
<!-- Fin du script php   d'initialisation -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Colorpicker avec PHP </title>
  <meta charset="utf-8">    

  <!-- style div d'id #couleur -->
  <style>
      #couleur {
          height:100pt; 
          width : 100pt;
          margin:auto; 
          border : 1pt solid black;
      }
      </style>
  </head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<p> Couleur de composantes R = <?php echo $r ; ?>, G = <?php echo $g ; ?> et B = <?php echo $b ; ?>.</p>
<div id="couleur"  <?php echo "style = 'background :".$rgb."'";?> >
</div>

    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
