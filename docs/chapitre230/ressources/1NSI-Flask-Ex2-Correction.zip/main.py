from flask import Flask, render_template, request
import datetime

#définition de l'application
app = Flask(__name__)


@app.route('/')
def defaut():  
   return render_template("index.html")
       

@app.route('/formulaire_age')
def formulaire_age():
   return render_template("formulaire_age.html")  

@app.route('/age',methods = ['POST', 'GET'])
def age():   
  if request.method == 'POST':
    assert request.form['a'], "Erreur de paramètres"
    annee_naissance = int(request.form['a'])   
  else: #requete GET
    assert request.args['a'], "Erreur de paramètres"
    annee_naissance = int(request.args.get('a', ''))
  annee_courante = datetime.date.today().year
  age = annee_courante - annee_naissance
  return render_template("age.html", annee_naissance = annee_naissance, annee_courante = annee_courante, age = age)


@app.route('/formulaire_rgb')
def formulaire_rgb():
   return render_template("formulaire_rgb.html")  


@app.route('/rgb',methods = ['POST', 'GET'])
def rgb():   
  r, g, b = 0, 0, 0
  if request.method == 'POST':
    assert request.form['r'] and request.form['g'] and request.form['b'], "Erreur de paramètres"
    r = int(request.form['r'])
    g = int(request.form['g'])
    b = int(request.form['b'])
  else: #requete GET
    assert request.args['r'] and request.args['g'] and request.args['b'], "Erreur de paramètres"
    r = int(request.args.get('r', ''))
    g = int(request.args.get('g', '')) 
    b = int(request.args.get('b', '')) 
  return render_template("rgb.html", r = r, g = g, b = b, couleur = f'rgb({r}, {g}, {b})')

def conversion_temperature(mesure_source, unite_source):
  if unite_source == 'celsius':
    return str(9 / 5 * mesure_source + 32)
  else:
    return str( 5 / 9 * (mesure_source- 32))

@app.route('/temperature',methods = ['POST', 'GET'])
def temperature():
  #initialisation du formulaire si pas de requete
  unite_source = 'celsius'
  unite_cible = 'fahrenheit'
  mesure_source = 0   
  #requete POST
  if request.method == 'POST':
    assert request.form['unite_source'] and request.form['mesure_source'], "Erreur de paramètres"
    unite_source = request.form['unite_source']
    mesure_source = int(request.form['mesure_source'])     
  elif len(request.args) > 0: #requete GET
    assert request.args['unite_source'] and request.args['mesure_source'], "Erreur de paramètres"
    unite_source = request.args.get('unite_source', '')
    mesure_source = int(request.args.get('mesure_source', '')) 
  if unite_source != 'celsius':       
    unite_cible = 'celsius'
  selection = {unite_source : 'selected', unite_cible : '' }
  return render_template("temperature.html", mesure_source = mesure_source, unite_source = unite_source, unite_cible = unite_cible, 
  selection = selection, conversion = conversion_temperature(mesure_source, unite_source))



if __name__ == "__main__":
  # on ouvre un serveur en local sur le port 8000
  app.run(debug = True, host='0.0.0.0', port=8000)

   