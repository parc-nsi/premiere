<!DOCTYPE html>

<!-- Script PHP-->
<?php 
$annee_courante = date("Y");
$annee_naissance = $_GET["a"];
$age = $annee_courante - $annee_naissance;
?>
<!-- Fin du script PHP -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Affichage de l'âge avec PHP </title>
  <meta charset="utf-8">    
</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

   <h1> Affichage de votre âge  avec PHP </h1>
   
   <p> Vous êtes né en  <?php echo $annee_naissance;?>,
     nous sommes en <?php echo $annee_courante;?>, 
     vous avez <?php echo $age;?> ans. 
   </p>
    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
