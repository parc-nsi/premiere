let compteur = 0;

function suivant(){
    compteur = compteur + 1;
    let v = document.getElementById("valeur");
    if (compteur <= 1) {
      v.innerHTML = compteur + " clic";
    }
    else {
      v.innerHTML = compteur + " clics";
    }          
}

function reinitialiser(){
    compteur = 0;
    let v = document.getElementById("valeur");
    v.innerHTML = compteur + " clic";
}


let bouton_clic = document.getElementById("bouton_clic");
bouton_clic.addEventListener("click", suivant);
let bouton_reset = document.getElementById("bouton_reset");
bouton_reset.addEventListener("click", reinitialiser);