 <!DOCTYPE html>

<html lang="fr">

<!-- Début en-tête -->
<head>

  <title>Web IHM avec PHP</title>

  <meta charset="utf-8">

</head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<!-- Titre H1-->
 <h1>Première NSI, Web et IHM,  programmation côté serveur avec PHP</h1>
 
<!-- Menu -->
<?php
include('menu.php');
?>

<!-- Documentation sur PHP -->
<?php
include('documentation.php');
?>


</div>


</body>
</html> 
