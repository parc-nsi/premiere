<!-- Documentation sur PHP -->
<section>
<h2>Documentation</h2>
<ul>
   <li> Miniserveur Web avec PHP sur clef USB <a href="https://www.usbwebserver.net/webserver/"> https://www.usbwebserver.net/webserver/</a> </li>
    <li>Sur le site de Romain Janvier <a href="http://nsi.janviercommelemois.fr/fichiers_pdf/feuille-php-initiation.pdf"> une fiche d'activité très complète sur PHP </a> </li>
    <li>Documentation de PHP : <a href="https://www.php.net/"> https://www.php.net/</a> </li>    
    <li>Configurer le rapport d'erreur dans le fichier php.ini :
    <a href=" https://openclassrooms.com/fr/courses/918836-concevez-votre-site-web-avec-php-et-mysql/4238821-configurez-php-pour-visualiser-les-erreurs">Tutoriel sur Open Classroom</a>
     </li>
</ul>
</section>
      