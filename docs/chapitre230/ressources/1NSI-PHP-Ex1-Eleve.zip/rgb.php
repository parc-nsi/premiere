<!DOCTYPE html>

<!-- script php  d'initialisation, à compléter -->
<?php
if (isset($_GET['r'])) {
    $r = $_GET['r'];
}
else {
    $r = 0;
}

$g = 0;  //modifier ici

$b = 0;  //modifier ici

$rgb = "rgb(" . $r . "," . $g. "," . $b . ")";  

?>
<!-- Fin du script php   d'initialisation -->

<html lang="fr">

<!-- Début en-tête -->
<head>
  <title>Colorpicker avec PHP </title>
  <meta charset="utf-8">    

  <!-- style div d'id #couleur -->
  <style>
      #couleur {
          height:100pt; 
          width : 100pt;
          margin:auto; 
          border : 1pt solid black;
      }
      </style>
  </head>
<!-- Fin en-tête -->

<!-- Début corps -->    
<body>

<p> Couleur de composantes R = <?php echo $r ; ?>, G =  <!-- modifier ici --> et B =  <!-- modifier ici --> .</p>

<div id="couleur"  <?php echo "style = 'background :". ""/*à modifier*/."'";?> >

</div>

    
<a href="index.php">Retour à l'accueil</a>

</body>
</html> 
