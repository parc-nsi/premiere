//gestionnaire d'événement clic pour l'élément bouton
function conversion_unite(){
    let u = document.getElementById("unite_source");
    let m = document.getElementById("mesure_source");
    let c = document.getElementById("unite_cible");
    let v = document.getElementById("valeur");
    if (u.value === 'celsius'){
        v.innerHTML = 9/5 * parseInt(m.value) + 32;
        c.innerHTML = 'fahrenheit';
    }
    //à compléter avec un bloc else
}

/* 
Compléter en attachant le  gestionnaire d'événement conversion_unite
 à l'élément #bouton pour l'événement click
*/

/* conversion par défaut au chargement de la page
décommenter la ligne suivante*/
//conversion_unite();

