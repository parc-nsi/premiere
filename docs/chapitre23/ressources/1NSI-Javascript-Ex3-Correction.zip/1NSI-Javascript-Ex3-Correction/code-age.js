//gestionnaire d'événement clic pour l'élément bouton
function calcul_age(){
    let n = document.getElementById("naissance");
    let naissance = parseInt(n.value);
    let date = new Date();
    let courant = date.getFullYear();
    let c = document.getElementById("courant");
    c.innerHTML = courant;
    let a = document.getElementById("age");
    a.innerHTML = courant - naissance;
}

//age par défaut :
calcul_age();

